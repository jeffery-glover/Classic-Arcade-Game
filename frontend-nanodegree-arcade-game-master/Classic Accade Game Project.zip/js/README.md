Find the file called index.html the the frontend-nanodegree-arcade-game-master folder
Right click on the file and hit open with (favorite browser, I recommend chrome)
Game will open in browser

To move player use arrow keys

The objective of the game is to get the player to reach the water on the far side
Be careful to not be hit by the bugs crossing the screen!